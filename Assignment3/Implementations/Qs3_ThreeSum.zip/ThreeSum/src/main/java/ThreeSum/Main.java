/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ThreeSum;

import Main.*;

/**
 *
 * @author jaspr_000
 */
public class Main {
    public static void main(String[] args) {
        ThreeSum ts = new ThreeSum();
        int arr1[] = {0, -1, 2, -3, 1};
        int arr2[] = {1, -2, 1, 0, 5};
        System.out.println("Triplets for {0, -1, 2, -3, 1}");
        ts.printTriplets(arr1);
        System.out.println("Triplets for {1, -2, 1, 0, 5}");
        ts.printTriplets(arr2);
    }
}
