/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author jaspr_000
 */
public class ThreeSum {
    
  public void printTriplets(int[] arr){
      int n = arr.length;
      boolean found = false;
      for(int i=0;i<n;i++){
          for(int j=i+1;j<n;j++){
              for(int k=j+1;k<n;k++){
                  if(arr[i]+arr[j]+arr[k] == 0){
                    found = true;
                    System.out.print(arr[i]);
                    System.out.print(" ");
                    System.out.print(arr[j]);
                    System.out.print(" ");
                    System.out.print(arr[k]);
                    System.out.print("\n");
                  }
              }
          }
      }
      if(found == false){
          System.out.println("TRIPLETS NOT FOUND");
      }
      
  }
    
    
}
