/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qs6b.c._factorial;

/**
 *
 * @author jaspr_000
 */
public class Qs6BC_Factorial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num = 6;
        CalculateFactorialRecursive cal = new CalculateFactorialRecursive();
        long factorial = cal.multiplyNumbers(num);
        System.out.println("Factorial of " + num + " = " + factorial);
    }
    
}
