/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qs1_power_iterative;

/**
 *
 * @author jaspr_000
 */
public class PowerIterative {
    
    public int getPower(int x, int n){
        int result = 1;
        for(int i=1;i<=n;i++){
            result *= x;
        }
        return result;   
    }
    
}
