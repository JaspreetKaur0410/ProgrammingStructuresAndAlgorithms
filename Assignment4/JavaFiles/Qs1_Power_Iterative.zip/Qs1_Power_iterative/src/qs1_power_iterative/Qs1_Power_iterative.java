/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qs1_power_iterative;

import java.util.Scanner;

/**
 *
 * @author jaspr_000
 */
public class Qs1_Power_iterative {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n=7;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number to calculate its 7th power");
        try{
           int x = sc.nextInt();
           PowerIterative pi = new PowerIterative();
            System.out.println(pi.getPower(x, n));
        }
        catch(Exception e){
            System.out.println("Please enter number");
        }
        
    }
    
}
