/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qs2.d._graytobinary;

/**
 *
 * @author jaspr_000
 */
public class GrayToBinary {
    
    char flip(char c)
    {
        return (c == '0') ? '1' : '0';
    }
    
    String graytoBinary(String gray)
    {
        String binary = "";
 
        // MSB of binary code is same
        // as gray code
        binary += gray.charAt(0);
 
        // Compute remaining bits
        for (int i = 1; i < gray.length(); i++)
        {
           
            // If current bit is 0,
            // concatenate previous bit
            if (gray.charAt(i) == '0')
                binary += binary.charAt(i - 1);
           
          // Else, concatenate invert of
            // previous bit
            else
                binary += flip(binary.charAt(i - 1));
        }
 
        return binary;
    }
    
}
