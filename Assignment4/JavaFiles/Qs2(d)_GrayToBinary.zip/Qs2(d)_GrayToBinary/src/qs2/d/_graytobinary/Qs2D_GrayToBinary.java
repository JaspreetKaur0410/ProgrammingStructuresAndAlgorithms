/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qs2.d._graytobinary;

/**
 *
 * @author jaspr_000
 */
public class Qs2D_GrayToBinary {

    /**
     * @param args the command line arguments
     */
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        String gray = "01101";
        GrayToBinary ob = new GrayToBinary();
        System.out.println("Binary code of "
                + gray + " is "
                + ob.graytoBinary(gray));
    }

}
