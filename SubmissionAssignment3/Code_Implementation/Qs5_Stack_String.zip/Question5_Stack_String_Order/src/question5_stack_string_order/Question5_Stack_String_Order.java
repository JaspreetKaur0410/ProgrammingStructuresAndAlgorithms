/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question5_stack_string_order;

import java.util.Arrays;
import java.util.Stack;

/**
 *
 * @author jaspr_000
 */
public class Question5_Stack_String_Order {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
      Stack<String> stack1 = new Stack<String>();
      Stack<String> stack2 = new Stack<String>();
      String input = "It was the best of time";
      String[] arr = input.split(" ");
      int size = arr.length;
      for(int i=0; i<size; i++) {
         stack1.push(arr[i]);
      }
      String[] res = new String[size];
      for(int i=0; i<size; i++) {
         stack2.push(stack1.pop());  
      }
      
      for(int i=0; i<size; i++) {
         res[i] = stack2.pop();
         System.out.print(res[i]+" ");
      }  
    }
    
}
