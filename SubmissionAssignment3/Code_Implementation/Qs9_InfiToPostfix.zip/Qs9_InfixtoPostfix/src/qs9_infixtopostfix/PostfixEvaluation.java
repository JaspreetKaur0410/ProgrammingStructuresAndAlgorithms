/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qs9_infixtopostfix;

import java.util.Stack;

/**
 *
 * @author jaspr_000
 */
public class PostfixEvaluation {
    
    static int Prec(char ch)
    {
        switch (ch)
        {
        case '+':
        case '-':
            return 1;
      
        case '*':
        case '/':
            return 2;
      
        case '^':
            return 3;
        }
        return -1;
    }

    public String postfixEvaluate(String input) {
        // initializing empty String for result
        String result = new String("");

        Stack<Character> stack = new Stack<>();
         
        for (int i = 0; i<input.length(); ++i)
        {
            char c = input.charAt(i);
            
            if (c == ' ')
                continue;
             
            // if current is a character
            else if (Character.isLetterOrDigit(c))
                result += c;
              
            // If the current '(',
            // push it to the stack.
            else if (c == '(')
                stack.push(c);
             
            //  If the current is an ')',
            // pop and output from the stack
            // until an '(' is encountered.
            else if (c == ')')
            {
                while (!stack.isEmpty() &&
                        stack.peek() != '(')
                    result += stack.pop();
                 
                    stack.pop();
            }
            
            // if current is an operator - pop from stack till precedence of top of stack operator is higher or equal to current operator
            else 
            {
                while (!stack.isEmpty() && Prec(c)
                         <= Prec(stack.peek())){
                   
                    result += stack.pop();
             }
                stack.push(c);
            }
      
        }
      
        // pop all the operators from the stack
        while (!stack.isEmpty()){
            if(stack.peek() == '(')
                return "Invalid Expression";
            result += stack.pop();
         }
        return result;
    }
}
