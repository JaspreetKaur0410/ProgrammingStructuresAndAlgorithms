/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qs9_infixtopostfix;

/**
 *
 * @author jaspr_000
 */
public class Qs9_InfixtoPostfix {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        PostfixEvaluation pe  = new PostfixEvaluation();
        String input = "(A + B) * C + D / (E + F * G) - H";
        String result = pe.postfixEvaluate(input);
        System.out.println("Result of Postfix Evaluation for (A + B) * C + D / (E + F * G) - H "+ " -> " +result);
    }
    
}
